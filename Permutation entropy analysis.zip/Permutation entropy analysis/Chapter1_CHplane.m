%Chapter 1
%Construction of CH-planes
%Functions used:H and C functions for the stochastic series (fBm) for CH-plane.The code 
% used to obtain the H and C functions of the chaotic series (Chaotic_Hfunction)is included.
% Curves function is also used for the construction of the minimum and maximum complexity curves
d = 3;% Can be changed to other dimensions
t = 1;
m = xlsread("Stochastic_Series_Sims.xlsx");
m = m(:,2:end);
Hstoc =[];
Cstoc = [];
tiledlayout(1,1)
ax(1) = nexttile;
for  b = 1:height(m)
y = m(b,:);
[Hstoc] = [Hstoc, H_function(y,d,t)];
[Cstoc] = [Cstoc, C_function(y,d,t)];
end
run("Chaotic_H")
[H_vecmax,C_vecmax] = Curves_function(d);
hold on
plot(Hstoc,Cstoc, '-')
plot(Hchao,Cchao, '.')
lh =legend(ax(1),'Location','NorthOutside','Orientation','Horizontal');
legend('Minimum complexity', 'Maximum complexity', 'fBm', 'Logistic map')
xlabel('H')
ylabel('C')