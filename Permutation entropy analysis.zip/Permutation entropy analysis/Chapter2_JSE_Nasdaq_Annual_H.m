%Chapter 2
%Data Analysed: JSE Top 40 and Nasdaq-100 from 2002 - 2021
%Data source: investing.com
%For illustration: Calculation of H value of Nasdaq-100 daily price for
%2016, as done in Section 2.4.3. Note that due to the varied number in
%trading days, the PE of each period was calculated individually. Hence, the
%data on the annual H values for the JSE Top 40 and Nasdaq-100 are imported 
% and the code used for plotting Figure 2.10 is shown.
%Function used: H_function for the calculation of permutation entropy, H
d = 3;
t = 1;
z = xlsread("Nasdaq2016.xlsx"); %imports data
y = (z(:,:))';
H = H_function(y,d,t);
%Plotting of annual H values for the JSE Top 40 and Nasdaq-100.
tiledlayout(1,1)
ax(1) = nexttile;
m = xlsread("Nasdaq_Annual_H_Values");
m = (m(:,2))';
n = xlsread("JSE_Annual_H_Values");
n = (n(:,2))';
years = 2002:2021;
numyears = length(years);
jan1s = zeros(numyears,1);
for Yearno = 1:numyears
 thisyear = years(Yearno);
 jan1s(Yearno) = datenum([thisyear 1 1]);
end
plot(jan1s(:),n)
hold on
plot(jan1s(:),m)
ylim([0.75,1]);
set(gca,'XTick', jan1s);
datetick('x', 'yyyy');
h =legend(ax(1),'Location','NorthOutside','Orientation','Horizontal');
legend('JSE Top 40', 'Nasdaq-100')
xlabel('Year')
ylabel('H')