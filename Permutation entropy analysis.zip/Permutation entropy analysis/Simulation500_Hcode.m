%Chapter 3
%Data Analysed: Tennessee Eastman Data
%Data source: Havard Dataverse
%For illustration:H values of the reactor temperature of Fault 14 as the
%fault is introduced, shown in Figure 4.3a (Simulation 500)
%%Function used: H_function for the calculation on permutation entropy, H
d = 3;
t = 2;
z = xlsread("TEP_F14.xlsx"); %imports data
m = (z(:,5))'; %Simulation 500
H500 =[];
for b = 1:161
y = m(:,b:b+119);
H500 = [H500,H_function(y,d,t)];
end
%plot(H500)