%If data is a column vector, transpose to row vector 
%This function is used for the calculation of the permutation entropy of a given time series 
function H = Hx_function(x,d,t) %y = data set, d = dimension, t = time delay
lx = length(x);
permlist = perms(1:d); %possible rankings
c(1:length(permlist))=0;
%Ranking of the elements   
 for j=1:lx-t*(d-1)
     [xsort,xrank]=sort(x(j:t:j+t*(d-1)));
     for jj=1:length(permlist)
         if (abs(permlist(jj,:)-xrank))==0
             c(jj) = c(jj) + 1;
         end
     end
 end
 
c=c(find(c~=0)); %number of occurrence of each possible ranking
p = c/sum(c); %probability vector P.
s_p = -sum(p .* log(p)); %S(P)
H = s_p/log(factorial(d)); %H(P).
end