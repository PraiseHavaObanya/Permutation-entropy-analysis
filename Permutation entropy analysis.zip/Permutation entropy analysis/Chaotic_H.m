%Chapter 1
%H and C values of chaotic series (logistic map) for CH-plane.
%Functions used:H_function and C_function 
%d = 3;% Can be changed to other dimensions
%t = 1;
m = xlsread("Chaotic_Series_Sims.xlsx");
m = m(:,2:end);
Hchao =[];
Cchao = [];
for  b = 1:height(m)
y = m(b,:);
[Hchao] = [Hchao, H_function(y,d,t)];
[Cchao] = [Cchao, C_function(y,d,t)];
end
