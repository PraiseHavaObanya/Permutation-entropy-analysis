%If data is a column vector, transpose to row vector 
%This function is used for the calculation of the permutation entropy of a given time series 
function H = H_function(y,d,t) %y = data set, d = dimension, t = time delay
ly = length(y);
permlist = perms(1:d); %possible rankings
c(1:length(permlist))=0;
%Ranking of the elements   
 for j=1:ly-t*(d-1)
     [ysort,yrank]=sort(y(j:t:j+t*(d-1)));
     for jj=1:length(permlist)
         if (abs(permlist(jj,:)-yrank))==0
             c(jj) = c(jj) + 1;
         end
     end
 end
 
c=c(find(c~=0)); %number of occurrence of each possible ranking
p = c/sum(c); %probability vector P.
s_p = -sum(p .* log(p)); %S(P)
H = s_p/log(factorial(d)); %H(P).
end