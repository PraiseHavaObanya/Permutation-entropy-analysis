function [Hvec,Cvec,H_vecmax,C_vecmax] = Curves_function(d)
[Hvec,Cvec] = Minimum_Curve_function(d);
[H_vecmax,C_vecmax] = Maximum_Curve_function(d);

