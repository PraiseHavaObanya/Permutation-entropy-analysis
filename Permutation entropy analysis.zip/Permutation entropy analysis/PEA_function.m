%If data is a column vector, transpose to row vector 
%This function is used to obtain both the permuatation entropy H and
%intensive statistical complexity C of a given time series.
function [H,C] = PEA_function(y,d,t) %y = data set, d = dimension, t = time delay
ly = length(y);
permlist = perms(1:d); %possible rankings
c(1:length(permlist))=0;
%Ranking of the elements    
 for j=1:ly-t*(d-1)
     [ysort,yrank]=sort(y(j:t:j+t*(d-1))); 
     for jj=1:length(permlist)
         if (abs(permlist(jj,:)-yrank))==0
             c(jj) = c(jj) + 1;
         end
     end
 end
c=c(find(c~=0)); %number of occurrence of each possible ranking
p = c/sum(c); %probability vector P
s_p = -sum(p .* log(p)); %S(P)
H = s_p/log(factorial(d)); %H(P)
% Further steps for the calculation of C
for j = 1:factorial(d)
p_j = (1/factorial(d))*ones(1,factorial(d)); %perfect entropy
end
if length(p) == length(p_j)
    p = p;
else
p = [p, zeros(1, length(p_j) - length(p))]; %Adds the zero elements removed in the calculation of H
end
s_pe = -(((1/factorial(d))*(log(1/factorial(d)))))*factorial(d);
P = p_j + p;
PP = P./2;
PP = PP.*log(PP);
S_PP = -(sum(PP));
q_0 = -2*((((factorial(d)+1)/factorial(d))*log(factorial(d)+ 1))-(2*log(2*factorial(d)))+(log(factorial(d))))^-1;
q_j = q_0*((S_PP) - (s_p/2) - (s_pe/2));
C = q_j*H; %C(P)