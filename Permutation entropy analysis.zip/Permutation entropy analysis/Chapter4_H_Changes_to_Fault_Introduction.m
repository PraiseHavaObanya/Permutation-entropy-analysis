%Chapter 3
%Data Analysed: Data sets of the Tennessee Eastman Process
%Data source: Havard Dataverse
%For illustration: H values of the reactor temperature of Fault 14 as the
%fault is introduced, shown in the bottom tile of Figure 4.3a
%%Function used: H_function for the calculation on permutation entropy, H
d = 3;
t = 2;
z = xlsread("TEP_F14.xlsx"); %imports data
m = (z(:,3))'; % Simulation 1, Results obtained from Simulations 377 and 500 are included in the code
H1 =[];
for b = 1:161
y = m(:,b:b+119);
H1 = [H1,H_function(y,d,t)];
end
run("Simulation377_Hcode")
run("Simulation500_Hcode")
tiledlayout(1,1)
ax(1) = nexttile;
x = 120:280;
plot(x,H1)
hold on
plot(x,H377)
hold on 
plot(x,H500)
xlim([0,280])
h =legend(ax(1),'Location','NorthOutside','Orientation','Horizontal');
legend('Sim 1', 'Sim 377', 'Sim 500')
xlabel('First 280 samples')
ylabel('H')

