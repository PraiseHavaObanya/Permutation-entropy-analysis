%Chapter 3
%The annual H values of Bitcoin volatility obtained from the SGARCH model,
%shown in Table 3.3.
d = 3;
t = 1;
m = xlsread("Sgarchvol_Nonleap_Years.xlsx");
m = (m(:,:))';
n = xlsread("Sgarchvol_Leap_Years.xlsx");
n = (n(:,:))';
Hvecnonleap =[];
Hvecleap =[];
for  b = 1:height(m)
y = m(b,:);
Hvecnonleap = [Hvecnonleap, Hy_function(y,d,t)];
end
for f = 1:height(n)
    x = n(f,:);
Hvecleap = [Hvecleap, Hx_function(x,d,t)];
end
Hsgarch = ([Hvecnonleap(:,1) Hvecleap(:,1) Hvecnonleap(:,2:4) Hvecleap(:,2) Hvecnonleap(:,5:6)])';






