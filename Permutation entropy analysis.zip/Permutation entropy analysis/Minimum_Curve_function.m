%This function is used for the deriavation of the minimum complexity curve,
%required for plotting CH-plane.
function [Hvec,Cvec] = Minimum_Curve_function(d) % d = dimension
p_k = linspace(1/(factorial(d)), 1, 10000);
p_rest = (1 - p_k)/(factorial(d) -1);
for i = 1:length(p_k)
    p_i = [p_k(1,i), p_rest(1,i)*(ones(1,factorial(d)-1))];
    s_i = -((p_k(1,i).*log(p_k(1,i))...
    + (p_rest(1,i).*log(p_rest(1,i)))*(factorial(d) - 1)));
    H_i = s_i./log(factorial(d));
 for j = 1:factorial(d)
     p_j = (1/factorial(d))*ones(1,factorial(d));
     s_p_j = -(((1/factorial(d))*(log(1/factorial(d)))))*factorial(d);
 end
     P_i = p_i + p_j;
     PP_i = P_i./2;
     s_PP_i = -sum(PP_i.*log(PP_i));
     q_0 = -2*((((factorial(d)+1)/factorial(d))*log(factorial(d)+ 1))...
         -(2*log(2*factorial(d)))+(log(factorial(d))))^-1;
     q_i = q_0*((s_PP_i) - (s_i/2) - (s_p_j/2));
     C_i = q_i.*H_i;
     Hvec(i) = H_i;
     Cvec(i) = C_i;
end
%f1 = figure;
plot(Hvec,Cvec, '.')
end