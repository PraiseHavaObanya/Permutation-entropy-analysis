%This function is used for the deriavation of the maximum complexity curve,
%required for plotting CH-plane.
function [H_vecmax,C_vecmax] = Maximum_Curve_function(d) % d = dimension
p_m = (1/factorial(d))*ones(1,factorial(d));
s_p_m = -(((1/factorial(d))*(log(1/factorial(d)))))*factorial(d);
for u = 1:factorial(d)-1
    p_f = linspace(0,1/((factorial(d))-u+1),10000);
    p_others = (1-p_f)/(factorial(d)-u);
 for v = 1:length(p_f)
     p_v = [p_f(1,v) p_others(1,v)*(ones(1,factorial(d)-u))...
         zeros(1,factorial(d) - (length(p_f(1,v)) +...
         length(p_others(1,v)*(ones(1,factorial(d)-u)))))];
     pp_v = nonzeros(p_v);
     s_v= -sum(pp_v.*log(pp_v));
     Hmax = s_v./log(factorial(d));
     Hvecmax(u,v) = Hmax;
     H_vecmax = transpose(Hvecmax);
    Pmax = p_v + p_m;
    PPmax = Pmax./2;
    s_PPmax = -sum(PPmax.*log(PPmax));
    q_0max = -2*((((factorial(d)+1)/factorial(d))*log(factorial(d)+ 1))...
         -(2*log(2*factorial(d)))+(log(factorial(d))))^-1;
    q = q_0max*((s_PPmax) - (s_v/2) - (s_p_m/2));
    C = q.*Hmax;
    Cvecmax(u,v) = C;
    C_vecmax = transpose(Cvecmax);
    H_vecmax = reshape(H_vecmax, 1,[]);
    C_vecmax = reshape(C_vecmax, 1,[]);
 end
end
%figure(f1);
hold on;
%f2 = figure;
plot(H_vecmax,C_vecmax, '.')
end
