%Chapter 3
%The annual H values of Bitcoin volatility obtained from the FIGARCH model,
%shown in Table 3.3.Here, the annual H values obtained from the SGARCH
%model (Sgarch_Hfunction.m) is included in this code. The results are
%displayed. Also, Table 3.3. is represented as a figure.
d = 3;
t = 1;
m = xlsread("Figarchvol_Nonleap_Years.xlsx");
m = (m(:,:))';
n = xlsread("Figarchvol_Leap_Years.xlsx");
n = (n(:,:))';
Hvecnonleap =[];
Hvecleap =[];
for  b = 1:height(m)
y = m(b,:);
Hvecnonleap = [Hvecnonleap, Hy_function(y,d,t)];
end
for f = 1:height(n)
    x = n(f,:);
Hvecleap = [Hvecleap, Hx_function(x,d,t)];
end
Hfigarch = ([Hvecnonleap(:,1) Hvecleap(:,1) Hvecnonleap(:,2:4) Hvecleap(:,2) Hvecnonleap(:,5:6)])';
run("Sgarch_H.m")
table = [Hfigarch,Hsgarch];
display(table)
tiledlayout(1,1)
ax(1) = nexttile;
years = 2015:2022;
numyears = length(years);
jan1s = zeros(numyears,1);
for Yearno = 1:numyears
 thisyear = years(Yearno);
 jan1s(Yearno) = datenum([thisyear 1 1]);
end
plot(jan1s(:),Hfigarch)
hold on
plot(jan1s(:),Hsgarch)
ylim([0.25,1]);
set(gca,'XTick', jan1s);
datetick('x', 'yyyy');
h =legend(ax(1),'Location','NorthOutside','Orientation','Horizontal');
legend('FIGARCH', 'SGARCH')
xlabel('Year')
ylabel('H')

